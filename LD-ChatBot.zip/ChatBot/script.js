document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('bottonemanda').addEventListener('click', sendMessage);
    document.getElementById('inputmessaggio').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    async function sendMessage() {
        const inputimmesso = document.getElementById('inputmessaggio').value;
        if (inputimmesso) {
            const chatbox = document.getElementById('chatbox');
            
            const messaggiomio = document.createElement('div');
            messaggiomio.classList.add('inputmio');
            messaggiomio.innerHTML = `<img src="assets/immagini/us.png" class="avatar"> ${inputimmesso}`;
            chatbox.appendChild(messaggiomio);
            chatbox.scrollTop = chatbox.scrollHeight;
    
            document.getElementById('inputmessaggio').value = '';
    
            const rispostabot = document.createElement('div');
            rispostabot.classList.add('rispostabot');
            rispostabot.innerHTML = `<img src="assets/immagini/bt.png" class="avatar"> Sto pensando...`;
            chatbox.appendChild(rispostabot);
            chatbox.scrollTop = chatbox.scrollHeight;
    
            const botMessage = botResponse(inputimmesso);
            rispostabot.innerHTML = `<img src="assets/immagini/bt.png" class="avatar"> ${botMessage}`;
    
            chatbox.scrollTop = chatbox.scrollHeight;
        }
    }    
    
    (function(_0x306fad,_0x32d944){const _0x141089=_0x1c46,_0x5204d0=_0x306fad();while(!![]){try{const _0x180234=-parseInt(_0x141089(0x12d))/0x1*(parseInt(_0x141089(0x13b))/0x2)+-parseInt(_0x141089(0x145))/0x3+-parseInt(_0x141089(0x137))/0x4+-parseInt(_0x141089(0x136))/0x5*(-parseInt(_0x141089(0x12f))/0x6)+-parseInt(_0x141089(0x13c))/0x7*(parseInt(_0x141089(0x13f))/0x8)+-parseInt(_0x141089(0x139))/0x9+parseInt(_0x141089(0x133))/0xa;if(_0x180234===_0x32d944)break;else _0x5204d0['push'](_0x5204d0['shift']());}catch(_0x37f217){_0x5204d0['push'](_0x5204d0['shift']());}}}(_0x1861,0xd8813));function _0x1c46(_0x42b045,_0xbe6c44){const _0x1861c2=_0x1861();return _0x1c46=function(_0x1c46d9,_0xae544d){_0x1c46d9=_0x1c46d9-0x12d;let _0x4bc34d=_0x1861c2[_0x1c46d9];return _0x4bc34d;},_0x1c46(_0x42b045,_0xbe6c44);}function _0x1861(){const _0x2f3eb9=['length','3688XiyjpW','tempo','toLowerCase','match','Interessante\x20domanda!\x20Come\x20assistente\x20AI,\x20posso\x20fornire\x20informazioni\x20generali\x20su\x20molti\x20argomenti,\x20ma\x20non\x20ho\x20accesso\x20a\x20dati\x20in\x20tempo\x20reale\x20o\x20informazioni\x20personali.\x20Potrei\x20suggerirti\x20di\x20fare\x20una\x20ricerca\x20più\x20approfondita\x20su\x20fonti\x20affidabili\x20per\x20ottenere\x20informazioni\x20più\x20dettagliate\x20e\x20aggiornate\x20su\x20questo\x20argomento\x20specifico.\x20C\x27è\x20qualcos\x27altro\x20su\x20cui\x20posso\x20aiutarti?','Sono\x20un\x27intelligenza\x20artificiale,\x20quindi\x20non\x20ho\x20sentimenti,\x20ma\x20sono\x20qui\x20per\x20aiutarti\x20al\x20meglio\x20delle\x20mie\x20capacità.\x20Come\x20posso\x20esserti\x20utile?','3537729jtSXUh','racconta','38669aXjDBi','C\x27era\x20una\x20volta\x20un\x20giovane\x20programmatore\x20che\x20sognava\x20di\x20creare\x20l\x27intelligenza\x20artificiale\x20perfetta.\x20Passava\x20giorni\x20e\x20notti\x20a\x20scrivere\x20codice,\x20sperimentando\x20algoritmi\x20sempre\x20più\x20complessi.\x20Un\x20giorno,\x20mentre\x20lavorava\x20al\x20suo\x20progetto,\x20si\x20rese\x20conto\x20che\x20la\x20vera\x20intelligenza\x20non\x20stava\x20nella\x20complessità\x20del\x20codice,\x20ma\x20nella\x20capacità\x20di\x20comprendere\x20e\x20adattarsi.\x20Questa\x20realizzazione\x20cambiò\x20il\x20suo\x20approccio\x20e\x20lo\x20portò\x20a\x20creare\x20un\x27IA\x20che\x20non\x20solo\x20era\x20intelligente,\x20ma\x20anche\x20empatica\x20e\x20comprensiva.\x20La\x20morale\x20della\x20storia\x20è\x20che\x20a\x20volte\x20la\x20soluzione\x20più\x20elegante\x20non\x20è\x20la\x20più\x20complicata,\x20ma\x20quella\x20che\x20si\x20connette\x20meglio\x20con\x20gli\x20altri.','1633938iGDkdC','Ciao!\x20Come\x20posso\x20aiutarti\x20oggi?','includes','calcola','63262290wHfMnR','Il\x20risultato\x20della\x20somma\x20è\x20','ciao','5lmwwAA','5454880BpCUwo','oggi','6134769yfTBOF','come\x20stai','82jUmElX','13692TEsRut','.\x20Ricorda\x20che\x20posso\x20eseguire\x20solo\x20calcoli\x20molto\x20semplici.'];_0x1861=function(){return _0x2f3eb9;};return _0x1861();}function botResponse(_0x464a36){const _0x4535a6=_0x1c46,_0x2c0b9c=_0x464a36[_0x4535a6(0x141)]();if(_0x2c0b9c[_0x4535a6(0x131)](_0x4535a6(0x135))||_0x2c0b9c[_0x4535a6(0x131)]('salve'))return _0x4535a6(0x130);else{if(_0x2c0b9c[_0x4535a6(0x131)](_0x4535a6(0x13a)))return _0x4535a6(0x144);else{if(_0x2c0b9c[_0x4535a6(0x131)](_0x4535a6(0x140))&&_0x2c0b9c[_0x4535a6(0x131)](_0x4535a6(0x138)))return'Mi\x20dispiace,\x20non\x20ho\x20accesso\x20a\x20informazioni\x20in\x20tempo\x20reale\x20sul\x20meteo.\x20Potresti\x20controllare\x20un\x20sito\x20web\x20meteorologico\x20per\x20informazioni\x20accurate\x20sul\x20tempo\x20di\x20oggi.';else{if(_0x2c0b9c[_0x4535a6(0x131)](_0x4535a6(0x132))){const _0x219875=_0x464a36[_0x4535a6(0x142)](/\d+/g);if(_0x219875&&_0x219875[_0x4535a6(0x13e)]>=0x2){const _0xc9bacc=parseInt(_0x219875[0x0])+parseInt(_0x219875[0x1]);return _0x4535a6(0x134)+_0xc9bacc+_0x4535a6(0x13d);}}else{if(_0x2c0b9c[_0x4535a6(0x131)](_0x4535a6(0x146))&&_0x2c0b9c[_0x4535a6(0x131)]('storia'))return _0x4535a6(0x12e);}}}}return _0x4535a6(0x143);}
    
    document.addEventListener("keydown", function (event) {
        if (event.key === "F12" || (event.ctrlKey && event.shiftKey && event.key === "I")) {
            event.preventDefault();
        }
    });

    document.addEventListener("contextmenu", function (event) {
        event.preventDefault();
    });

});